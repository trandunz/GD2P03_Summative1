CREATED BY WILLIAM INMAN

AVAILABLE COMMANDS
------------------
PUT - saves a message from the client
GET - returns the current saved massage for the client
CAPITALIZE - capitalizes the inputed command
QUIT - Quits the client application
TIME - Returns current server time and date

BONUS FEATURES
--------------
THE CLIENT AND SERVER CAN BOTH BE DISCONNECTED/CLOSED WITHOUGHT ISSUES
THE CLIENT MAY CHOOSE TO RECONNECT TO A SERVER IF THEY ARE DISCONNECTED FOR WHATEVER REASON

LIMITATIONS
--------------
ALL MESSAGES ARE CAPPED TO A SIZE OF 100
REQUIRES A MINIMUM THREAD COUNT OF 2


C++ 11 FEATURES
---------------
Uniform Initialization (e.g sockaddr_in serverAddr { AF_INET , htons(_port), INADDR_ANY };) - 1

std::vector::emplace_back (e.g m_ConnectedSockets.emplace_back(client);) - 2

lambda's (e.g [this](int _client,char* _buffer,bool _finished) - 3
					{
						SendMessageToClient(_client,m_SavedMesssages[_client]);
					}, true });
			
constexpr (e.g constexpr int BUFFER_SIZE = 100;) - 4

Range-based for loop (e.g for (auto& socket : m_SavedMesssages) - 5
							{
								closesocket(socket.first);
							}
						
std::function (e.g std::function<void(int _client, bool _finished)> function{nullptr};) - 6

alias declaration (e.g using commandFunction = std::function<void(int _client, bool _finished)>;) - 7

auto (e.g auto version = MAKEWORD(1, 1);) - 8